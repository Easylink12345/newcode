document.addEventListener('DOMContentLoaded', () => {
  const cells = document.querySelectorAll('.cell');
  const status = document.getElementById('status');
  const resetBtn = document.getElementById('resetBtn');
  let currentPlayer = 'X';
  let gameActive = true;
  let board = ['', '', '', '', '', '', '', '', ''];

  const checkWinner = () => {
    const winningConditions = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6]
    ];

    for (let condition of winningConditions) {
      const [a, b, c] = condition;
      if (board[a] && board[a] === board[b] && board[a] === board[c]) {
        gameActive = false;
        cells[a].style.backgroundColor = '#2ecc71'; // Winner cells color
        cells[b].style.backgroundColor = '#2ecc71';
        cells[c].style.backgroundColor = '#2ecc71';
        status.textContent = `${currentPlayer} wins!`;
        return;
      }
    }

    if (!board.includes('')) {
      gameActive = false;
      status.textContent = `It's a draw!`;
    }
  };

  const handleCellClick = (index) => {
    if (gameActive && !board[index]) {
      board[index] = currentPlayer;
      cells[index].textContent = currentPlayer;
      checkWinner();
      currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    }
  };

  const handleReset = () => {
    board = ['', '', '', '', '', '', '', '', ''];
    currentPlayer = 'X';
    gameActive = true;
    status.textContent = '';
    cells.forEach((cell, index) => {
      cell.textContent = '';
      cell.style.backgroundColor = index % 2 === 0 ? '#2ecc71' : '#3498db'; // Reset cell colors
    });
  };

  cells.forEach((cell, index) => {
    cell.addEventListener('click', () => handleCellClick(index));
  });

  resetBtn.addEventListener('click', handleReset);
});
